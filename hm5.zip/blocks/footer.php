<h2><?= date('Y')?></h2>
<p>Copyright &copy; S1grud </p>